
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Akun telah masuk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body{
            background: url("https://png.pngtree.com/thumb_back/fw800/background/20200907/pngtree-hand-drawn-blackboard-education-background-image_398165.jpg");
        }
    </style>
</head>
<body>
<div class="container">
            <div class="col-sm-9 col-lg-5 mx-auto">
                <div class="card border-0 shadow rounded-3 my-5">
                    <div class="card-body p-4 p-sm-5">
        <h1 class="pt-2">Selamat Datang </h1>
        <a href="datausers.php" class="btn btn-primary">Data Users</a>
        <a href="homepage.php" class="btn btn-danger my-5">Logout</a>
    </div>
    </div>
            </div>
        </div>
</body>
</html>