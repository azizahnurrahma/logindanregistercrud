<?php

// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "datausers");


function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}


function registrasi ($data) {
	global $conn;

	$username = htmlspecialchars(strtolower (stripslashes ($data["username"])));
	$name = htmlspecialchars($data["name"]);
	$email = htmlspecialchars($data["email"]);
	$password = mysqli_real_escape_string($conn, $data["password"]);

	$password2 = mysqli_real_escape_string($conn, $data["password2"]);

	// username sudah ada atau belum
	$result = mysqli_query($conn,"SELECT username FROM user WHERE username ='$username'");

	if ( mysqli_fetch_assoc($result)) {
		echo "<script>
				alert('username sudah terdaftar!')
				</script>";
			return false;
	}
	// email sudah terdaftar atau belum
	$result2 = mysqli_query($conn, "SELECT email FROM user WHERE email ='$email'");

	if (mysqli_fetch_assoc($result2 )) {
		echo "<script>
				alert ('email sudah terdaftar!')
				</script>";
				return false;
	}

	// konfirmasi passsword
	if ($password !== $password2) {
		echo "<script>
			alert('konfirmasi password tidak sesuai')
			</script>";
			return false;
	}

	// enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);
	// tambahkan userbaru k database

	mysqli_query($conn, "INSERT INTO user VALUES('', '$username', '$name', '$email', '$password')");
	 return mysqli_affected_rows($conn);
}
function hapus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM user WHERE id = $id");
	return mysqli_affected_rows($conn);
}
function ubah($data) {
	global $conn;
	$id = $data["id"];
	$username = htmlspecialchars($data["username"]);
	$email = htmlspecialchars($data["email"]);
	$password = mysqli_real_escape_string( $conn, $data["password"]);
	$query = "UPDATE user SET 
				username = '$username',
				email = '$email',
				password = '$password'
			WHERE id = $id
				";
	mysqli_query($conn,$query);

	return mysqli_affected_rows($conn);

}
function tambah($data) {
	
	global $conn;
	$username = htmlspecialchars($data["username"]); 
 	$name = htmlspecialchars($data["name"]);
 	$email = htmlspecialchars($data["email"]);
 	$password = mysqli_real_escape_string($conn, $data["password"]);


 	$query = "INSERT INTO user
 				VALUES 
 				('','$username', '$name','$email','$password')
 				";
 	mysqli_query($conn, $query);

 	return mysqli_affected_rows($conn);
}
?>