<?php
require 'function.php';
// cek tombol submit
 if ( isset($_POST["submit"])) {
// cek berhasil ditambah atau tidak
    if ( tambah($_POST) > 0){
        echo "
        <script>
            alert('data berhasil ditambahkan');
            document.location.href = 'datausers.php';
        </script>
        ";

    } else {
        echo "
        <script>
            alert('data gagal ditambahkan');
            document.location.href = 'datausers.php';
        </script>
        "; 
    }
 }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<style>
        body{
            background: url("https://png.pngtree.com/thumb_back/fw800/background/20200907/pngtree-hand-drawn-blackboard-education-background-image_398165.jpg");
        }
    </style>
<body>
    <div class="container py-5" >
        <h1>Menambah data user</h1>
        <br><br>
        <form class="col col-sm-5 col-lg-6 col-md-7" action="" method="post">
            <input type="hidden" name="id">
            <div class="mb-2">
                <label class="form-label"><b>Username</b></label>
                <input type="text" name="username" class="form-control" >
            </div>
            <div class="mb-2">
                <label class="form-label"><b>Name</b></label>
                <input type="text" name="name" class="form-control" >
            </div>
            <div class="mb-2">
                <label class="form-label"><b>Email</b></label>
                <input type="email" name="email"  class="form-control" >
            </div>
            <div class="mb-2">
                <label class="form-label"><b>Password</b></label>
                <input type="password" name="password" class="form-control">
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>