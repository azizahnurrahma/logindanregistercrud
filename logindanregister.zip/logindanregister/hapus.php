<?php
require 'function.php';
$id = $_GET['id'];
    $result = mysqli_query($conn, "SELECT * FROM user WHERE id=$id");
    $row = mysqli_fetch_assoc($result);


    $result = mysqli_query($conn, "DELETE FROM user WHERE id=$id");
    if ($result) {
        header('location: dataUsers.php');
}
if ( hapus ($id) > 0) {
	echo "
 		<script>
 			alert('data berhasil dihapus');
 			document.location.href = 'index.php';
 		</script>
 		";
 	} else {
 		echo "
 		<script>
 			alert('data gagal dihapus');
 			document.location.href = 'index.php';
 		</script>
 		";
 	}
?>