<?php
    require 'function.php';
    // get data from database in id
    $id = $_GET['id'];
    $result = mysqli_query($conn, "SELECT * FROM user WHERE id=$id");
    $row = mysqli_fetch_assoc($result);

    if (isset($_POST['submit'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = empty($_POST['password']) ? $row['password'] : md5($_POST['password']);

        $result = mysqli_query($conn, "UPDATE user SET username='$username', email='$email', password='$password' WHERE id=$id");
        if ($result) {
            header('location: datausers.php');
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<style>
        body{
            background: url("https://png.pngtree.com/thumb_back/fw800/background/20200907/pngtree-hand-drawn-blackboard-education-background-image_398165.jpg");
        }
    </style>
<body>
    <div class="container py-5" >
        <h1>Mengubah data user</h1>
        <br><br>
        <form class="col col-sm-5 col-lg-6 col-md-7" action="" method="post">
            <input type="hidden" name="id">
            <div class="mb-2">
                <label class="form-label"><b>Username</b></label>
                <input type="text" name="username" class="form-control" >
            </div>
            <div class="mb-2">
                <label class="form-label"><b>Email</b></label>
                <input type="email" name="email"  class="form-control" >
            </div>
            <div class="mb-2">
                <label class="form-label"><b>Password</b></label>
                <input type="password" name="password" class="form-control">
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>